
$(document).ready(function(){
						   
$(".newSet").val("Try Again");					   
$(".background").hide();						   
						   })

