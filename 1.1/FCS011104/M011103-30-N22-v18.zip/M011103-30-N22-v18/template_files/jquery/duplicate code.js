			 /*for fourth algo*/
				 for (var i = 0; i<array_Range4; i++) {
				var num = randRange(5, 8);
				var gap = randRange(9, 13);
				num1 = num;
				num2 = num1+gap;
				num3 = num2+gap;
				num4 = num3+gap;
				num5 = num4+gap;
				ans = num5+gap;
				Q4_Arr.push(num1+"@"+num2+"@"+num3+"@"+num4+"@"+num5+"@"+ans);
				Q4_Arr = Remove_Duplicate_Entry(String(Q4_Arr))
				 }
				 
				 													 /*for fifth algo*/
				 for (var i = 0; i<array_Range5; i++) {
				var num = randRange(9, 13);
				var gap = randRange(9, 13);
				num1 = num;
				num2 = num1+gap;
				num3 = num2+gap;
				num4 = num3+gap;
				num5 = num4+gap;
				ans = num5+gap;
				Q5_Arr.push(num1+"@"+num2+"@"+num3+"@"+num4+"@"+num5+"@"+ans);
				Q5_Arr = Remove_Duplicate_Entry(String(Q5_Arr))
				 }
				 
				 													 /*for sixth algo*/
				 for (var i = 0; i<array_Range6; i++) {
				var num = randRange(9, 13);
				var gap = randRange(14, 20);
				num1 = num;
				num2 = num1+gap;
				num3 = num2+gap;
				num4 = num3+gap;
				num5 = num4+gap;
				ans = num5+gap;
				Q6_Arr.push(num1+"@"+num2+"@"+num3+"@"+num4+"@"+num5+"@"+ans);
				Q6_Arr = Remove_Duplicate_Entry(String(Q6_Arr))
				 }
				 
				 													 /*for seventh algo*/
				 for (var i = 0; i<array_Range7; i++) {
				var num = randRange(14, 20);
				var gap = randRange(14, 20);
				num1 = num;
				num2 = num1+gap;
				num3 = num2+gap;
				num4 = num3+gap;
				num5 = num4+gap;
				ans = num5+gap;
				Q7_Arr.push(num1+"@"+num2+"@"+num3+"@"+num4+"@"+num5+"@"+ans);
				Q7_Arr = Remove_Duplicate_Entry(String(Q7_Arr))
				 }
				 
				 													 /*for eighth algo*/
				 for (var i = 0; i<array_Range8; i++) {
				var num = randRange(14, 20);
				var gap = randRange(21, 25);
				num1 = num;
				num2 = num1+gap;
				num3 = num2+gap;
				num4 = num3+gap;
				num5 = num4+gap;
				ans = num5+gap;
				Q8_Arr.push(num1+"@"+num2+"@"+num3+"@"+num4+"@"+num5+"@"+ans);
				Q8_Arr = Remove_Duplicate_Entry(String(Q8_Arr))
				 }
				 
				 													 /*for ninth algo*/
				 for (var i = 0; i<array_Range9; i++) {
				var num = randRange(21, 25);
				var gap = randRange(21, 25);
				num1 = num;
				num2 = num1+gap;
				num3 = num2+gap;
				num4 = num3+gap;
				num5 = num4+gap;
				ans = num5+gap;
				Q9_Arr.push(num1+"@"+num2+"@"+num3+"@"+num4+"@"+num5+"@"+ans);
				Q9_Arr = Remove_Duplicate_Entry(String(Q9_Arr))
				 }
				 
				 													 /*for tenth algo*/
				 for (var i = 0; i<array_Range1; i++) {
				var num = randRange(25, 30);
				var gap = randRange(25, 30);
				num1 = num;
				num2 = num1+gap;
				num3 = num2+gap;
				num4 = num3+gap;
				num5 = num4+gap;
				ans = num5+gap;
				Q10_Arr.push(num1+"@"+num2+"@"+num3+"@"+num4+"@"+num5+"@"+ans);
				Q10_Arr = Remove_Duplicate_Entry(String(Q10_Arr))
				 }